-- Create the database if it does not exist
CREATE DATABASE IF NOT EXISTS db_artwork_php;

-- Switch to the newly created or existing database
USE db_artwork_php;

-- Create the 'tb_Artwork' table if it does not exist
CREATE TABLE IF NOT EXISTS tb_Artwork (
    id INT PRIMARY KEY AUTO_INCREMENT,
    artwork_name VARCHAR(250) NOT NULL UNIQUE,
    price INT NOT NULL,
    description VARCHAR(250),
    image VARCHAR(250)
);

-- create database db_artwork_php;

-- use db_artwork_php;

-- create table tb_Artwork
-- (
--     id int primary key auto_increment,
--     artwork_name varchar(250) not null unique,
--     price int not null,
--     description varchar(250),
--     image varchar(250)
-- );

CREATE TABLE tb_user
(
    user_id INT PRIMARY KEY auto_increment,
    user_name VARCHAR(50) NOT NULL,
    contact VARCHAR(50) NOT NULL UNIQUE,
    ADDRESS VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    user_password VARCHAR(250) NOT NULL
);
