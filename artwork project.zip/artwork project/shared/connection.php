<?php
// db connection code
try {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "db_artwork_php";
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>