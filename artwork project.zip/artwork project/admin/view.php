<?php
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD - View Artwork</title>
    <link rel="icon" type="image/x-icon" href="logo.png">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <!--  navbar -->
    <!-- <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.html">
                <img src="logo.png" alt="" width="30" height="24" class="d-inline-block align-text-top">
                CRUD -->
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="create.html">Add Artwork</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="list.html">Artworks List</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- view Artwork form -->
    <div class="container">
        <h1 class="text-center my-5">Artwork Details</h1>
        <div class="table-responsive">
            <table class="table">
                <tbody>
                    <tr>
                        <th scope="row">Artwork Name</th>
                        <td>Apple</td>
                    </tr>
                    <tr>
                        <th scope="row">Price</th>
                        <td>25</td>
                    </tr>
                    <tr>
                        <th scope="row">Long Description</th>
                        <td>Description</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- footer -->
    <!-- <div class="container-fluid bg-dark text-light p-2 text-center mt-5">
        &copy; Aneel Raja
    </div> -->

    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
include 'footer.php';
?>