<?php

include 'header.php';

echo "-----------------------------";

include 'footer.php';

?>