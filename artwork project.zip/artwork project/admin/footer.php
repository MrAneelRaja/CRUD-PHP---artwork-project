<!-- footer -->
<div class="container-fluid bg-dark text-light p-2 text-center mt-5">
        &copy; Aneel Raja
    </div>

    <script src="template/js/bootstrap.bundle.min.js"></script>
</body>

</html>